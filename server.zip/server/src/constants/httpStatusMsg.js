export const httpStatusMsg = {
    // General
    SUCCESS: "success",
    ERROR: "error",
    NOT_FOUND: "not_found",
    BAD_REQUEST: "bad_request",

    // Auth
    UNAUTHENTICATED: "unauthenticated",
    UNAUTHORIZED: "unauthorized",
    ACCESS_DENIED: "access_denied",
    INVALID_TOKEN: "invalid_token",
    TOKEN_EXPIRED: "token_expired",
    TOKEN_MISSING: "token_missing",
    INVALID_CREDENTIALS: "invalid_credentials",
    ACCOUNT_DEACTIVATED: "account_deactivated",

    // Validation
    VALIDATION_FAILED: "validation_failed",
    INVALID_INPUT: "invalid_input",
    MISSING_FIELDS: "missing_fields",

    // Resource
    ALREADY_EXISTS: "already_exists",
    RESOURCE_NOT_FOUND: "resource_not_found",
    RESOURCE_CREATED: "resource_created",
    RESOURCE_UPDATED: "resource_updated",
    RESOURCE_DELETED: "resource_deleted",

    // User / Donor / Org specific
    USER_NOT_FOUND: "user_not_found",
    DONOR_NOT_FOUND: "donor_not_found",
    ORG_NOT_FOUND: "organization_not_found",
    ORG_NOT_APPROVED: "organization_not_approved",
    ORG_PENDING: "organization_pending_approval",
    ORG_REJECTED: "organization_rejected",
    ORG_SUSPENDED: "organization_suspended",
    ALREADY_REGISTERED: "already_registered",
    ALREADY_RESPONDED: "already_responded",
    DONOR_INELIGIBLE: "donor_ineligible",

    // Campaign / Emergency
    CAMPAIGN_NOT_FOUND: "campaign_not_found",
    CAMPAIGN_CLOSED: "campaign_not_accepting_registrations",
    EMERGENCY_NOT_FOUND: "emergency_request_not_found",
    EMERGENCY_UNAVAILABLE: "emergency_request_not_available",
    REQUEST_FULFILLED: "request_already_fulfilled",

    // Server
    INTERNAL_ERROR: "internal_server_error",
    SERVICE_UNAVAILABLE: "service_unavailable",
};
