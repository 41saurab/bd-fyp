import express from "express";
import authRouter from "../modules/auth/authRoute.js";
import donorRouter from "../modules/donor/donorRoute.js";
import organizationRouter from "../modules/organization/organizationRoute.js";
import adminRouter from "../modules/admin/adminRoute.js";
import campaignRouter from "../modules/campaign/campaignRoute.js";
import emergencyRouter from "../modules/emergency/emergencyRoute.js";
import notificationRouter from "../modules/notification/notificationRoute.js";

const router = express.Router();

// Auth routes (register donor, register org, login, /me)
router.use("/auth", authRouter);

// Donor profile routes
router.use("/donors", donorRouter);

// Organization routes
router.use("/organizations", organizationRouter);

// Admin routes
router.use("/admin", adminRouter);

// Campaign routes
router.use("/campaigns", campaignRouter);

// Emergency routes
router.use("/emergency", emergencyRouter);

// Notification routes
router.use("/notifications", notificationRouter);

export default router;
