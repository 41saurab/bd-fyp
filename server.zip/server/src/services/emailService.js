import transporter from "../configs/emailConfig.js";

class EmailService {
	async sendEmail({ to, subject, html, text }) {
		try {
			const mailOptions = {
				from: `${process.env.EMAIL_FROM_NAME} <${process.env.EMAIL_USER}>`,
				to,
				subject,
				html,
				text: text || "",
			};

			const info = await transporter.sendMail(mailOptions);
			console.log(`Email sent: ${info.messageId}`);
			return { success: true, messageId: info.messageId };
		} catch (error) {
			console.error(`Email sending failed: ${error}`);
			return { success: false, error: error.message };
		}
	}

	// welcome email when donor register
	async sendDonorWelcomeEmail(donor) {
		const subject = "Welcome to Blood Donation System - Registration Successful! 🩸";
		const html = `
        <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Welcome to BloodDonate</title>
            </head>
            <body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #f5f5f5;">
                <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f5f5f5;">
                    <tr>
                        <td style="padding: 40px 20px;">
                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.07);">
                                
                                <!-- Header with gradient -->
                                <tr>
                                    <td style="background: linear-gradient(135deg, #dc2626 0%, #b91c1c 100%); padding: 48px 40px; text-align: center;">
                                        <div style="background-color: rgba(255, 255, 255, 0.2); width: 80px; height: 80px; border-radius: 50%; margin: 0 auto 24px; line-height: 80px; font-size: 40px;">
                                            ❤️
                                        </div>
                                        <h1 style="margin: 0 0 12px 0; color: #ffffff; font-size: 32px; font-weight: 700; letter-spacing: -0.5px;">Welcome to BloodDonate</h1>
                                        <p style="margin: 0; color: rgba(255, 255, 255, 0.95); font-size: 16px; line-height: 1.5;">Your journey as a life-saver begins today</p>
                                    </td>
                                </tr>

                                <!-- Greeting Section -->
                                <tr>
                                    <td style="padding: 40px 40px 32px 40px;">
                                        <h2 style="margin: 0 0 16px 0; color: #1f2937; font-size: 24px; font-weight: 600;">Hello, ${donor.name}</h2>
                                        <p style="margin: 0; color: #6b7280; font-size: 16px; line-height: 1.6;">Thank you for becoming a blood donor. Your contribution has the power to save up to <strong style="color: #dc2626;">3 lives</strong> with every donation.</p>
                                    </td>
                                </tr>

                                <!-- Profile Card -->
                                <tr>
                                    <td style="padding: 0 40px 32px 40px;">
                                        <div style="background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%); border-radius: 12px; padding: 28px; border: 1px solid #fecaca;">
                                            <h3 style="margin: 0 0 20px 0; color: #991b1b; font-size: 18px; font-weight: 600;">
                                                Your Donor Profile
                                            </h3>
                                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                <tr>
                                                    <td style="padding: 12px 0; border-bottom: 1px solid rgba(220, 38, 38, 0.1);">
                                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                            <tr>
                                                                <td style="color: #7f1d1d; font-size: 14px; font-weight: 500; width: 35%;">Blood Type</td>
                                                                <td style="color: #dc2626; font-size: 18px; font-weight: 700; text-align: right;">${donor.bloodType}</td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="padding: 12px 0; border-bottom: 1px solid rgba(220, 38, 38, 0.1);">
                                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                            <tr>
                                                                <td style="color: #7f1d1d; font-size: 14px; font-weight: 500; width: 35%;">Email</td>
                                                                <td style="color: #991b1b; font-size: 14px; text-align: right;">${donor.email}</td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="padding: 12px 0; border-bottom: 1px solid rgba(220, 38, 38, 0.1);">
                                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                            <tr>
                                                                <td style="color: #7f1d1d; font-size: 14px; font-weight: 500; width: 35%;">Phone</td>
                                                                <td style="color: #991b1b; font-size: 14px; text-align: right;">${donor.phone}</td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="padding: 12px 0;">
                                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                            <tr>
                                                                <td style="color: #7f1d1d; font-size: 14px; font-weight: 500; width: 35%;">Location</td>
                                                                <td style="color: #991b1b; font-size: 14px; text-align: right;">${donor.city}</td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </table>
                                        </div>
                                    </td>
                                </tr>

                                <!-- What's Next Section -->
                                <tr>
                                    <td style="padding: 0 40px 32px 40px;">
                                        <h3 style="margin: 0 0 24px 0; color: #1f2937; font-size: 20px; font-weight: 600;">What's Next</h3>
                                        
                                        <!-- Feature 1 -->
                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-bottom: 20px;">
                                            <tr>
                                                <td style="width: 48px; vertical-align: top; padding-top: 2px;">
                                                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%); border-radius: 10px; text-align: center; line-height: 40px; font-size: 20px;">
                                                        ✓
                                                    </div>
                                                </td>
                                                <td style="padding-left: 16px;">
                                                    <h4 style="margin: 0 0 6px 0; color: #1f2937; font-size: 16px; font-weight: 600;">Account Activated</h4>
                                                    <p style="margin: 0; color: #6b7280; font-size: 14px; line-height: 1.5;">Your donor profile is now live and ready to make a difference.</p>
                                                </td>
                                            </tr>
                                        </table>

                                        <!-- Feature 2 -->
                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-bottom: 20px;">
                                            <tr>
                                                <td style="width: 48px; vertical-align: top; padding-top: 2px;">
                                                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%); border-radius: 10px; text-align: center; line-height: 40px; font-size: 20px;">
                                                        🔔
                                                    </div>
                                                </td>
                                                <td style="padding-left: 16px;">
                                                    <h4 style="margin: 0 0 6px 0; color: #1f2937; font-size: 16px; font-weight: 600;">Smart Notifications</h4>
                                                    <p style="margin: 0; color: #6b7280; font-size: 14px; line-height: 1.5;">Get alerts when your blood type is urgently needed nearby.</p>
                                                </td>
                                            </tr>
                                        </table>

                                        <!-- Feature 3 -->
                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                            <tr>
                                                <td style="width: 48px; vertical-align: top; padding-top: 2px;">
                                                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); border-radius: 10px; text-align: center; line-height: 40px; font-size: 20px;">
                                                        ⏰
                                                    </div>
                                                </td>
                                                <td style="padding-left: 16px;">
                                                    <h4 style="margin: 0 0 6px 0; color: #1f2937; font-size: 16px; font-weight: 600;">Availability Control</h4>
                                                    <p style="margin: 0; color: #6b7280; font-size: 14px; line-height: 1.5;">Update your donation availability anytime from your dashboard.</p>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>

                                <!-- Divider -->
                                <tr>
                                    <td style="padding: 0 40px;">
                                        <div style="border-top: 2px solid #f3f4f6;"></div>
                                    </td>
                                </tr>
                               
                                <!-- Footer -->
                                <tr>
                                    <td style="padding: 32px 40px; border-top: 1px solid #e5e7eb;">
                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                            <tr>
                                                <td style="text-align: center;">
                                                    <p style="margin: 0 0 16px 0; color: #9ca3af; font-size: 13px; line-height: 1.6;">© ${new Date().getFullYear()} BloodDonate. All rights reserved.</p>
                                                    <p style="margin: 0 0 12px 0; color: #9ca3af; font-size: 12px; line-height: 1.6;">This is an automated email. Please do not reply.</p>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>

                            </table>
                        </td>
                    </tr>
                </table>
            </body>
            </html>
    `;
		return await this.sendEmail({ to: donor.email, subject, html });
	}

	// welcome email when organization register
	async sendOrganizationRegistrationEmail(organization) {
		const subject = "Welcome to Blood Donation System - Pending Vefification!";
		const html = `
            <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Registration Received - BloodDonate</title>
                </head>
                <body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #f5f5f5;">
                    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f5f5f5;">
                        <tr>
                            <td style="padding: 40px 20px;">
                                <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.07);">
                                    
                                    <!-- Header with gradient -->
                                    <tr>
                                        <td style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); padding: 48px 40px; text-align: center;">
                                            <div style="background-color: rgba(255, 255, 255, 0.2); width: 80px; height: 80px; border-radius: 50%; margin: 0 auto 24px; line-height: 80px; font-size: 40px;">
                                                🏥
                                            </div>
                                            <h1 style="margin: 0 0 12px 0; color: #ffffff; font-size: 32px; font-weight: 700; letter-spacing: -0.5px;">Registration Received!</h1>
                                            <p style="margin: 0; color: rgba(255, 255, 255, 0.95); font-size: 16px; line-height: 1.5;">Thank you for joining BloodDonate</p>
                                        </td>
                                    </tr>

                                    <!-- Greeting Section -->
                                    <tr>
                                        <td style="padding: 40px 40px 32px 40px;">
                                            <h2 style="margin: 0 0 16px 0; color: #1f2937; font-size: 24px; font-weight: 600;">Dear ${organization.organizationName},</h2>
                                            <p style="margin: 0; color: #6b7280; font-size: 16px; line-height: 1.6;">Thank you for registering with BloodDonate. We have received your application and are excited to have you join our network of life-saving organizations.</p>
                                        </td>
                                    </tr>

                                    <!-- Warning Box -->
                                    <tr>
                                        <td style="padding: 0 40px 32px 40px;">
                                            <div style="background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); border-left: 4px solid #f59e0b; border-radius: 8px; padding: 24px;">
                                                <h3 style="margin: 0 0 12px 0; color: #92400e; font-size: 18px; font-weight: 600;">
                                                    ⏳ Verification Pending
                                                </h3>
                                                <p style="margin: 0; color: #78350f; font-size: 15px; line-height: 1.6;">Your organization is currently under review by our admin team. This typically takes <strong>24-48 hours</strong>.</p>
                                            </div>
                                        </td>
                                    </tr>

                                    <!-- Submitted Information Card -->
                                    <tr>
                                        <td style="padding: 0 40px 32px 40px;">
                                            <div style="background: linear-gradient(135deg, #f3e8ff 0%, #e9d5ff 100%); border-radius: 12px; padding: 28px; border: 1px solid #d8b4fe;">
                                                <h3 style="margin: 0 0 20px 0; color: #6b21a8; font-size: 18px; font-weight: 600;">
                                                    📋 Submitted Information
                                                </h3>
                                                <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                    <tr>
                                                        <td style="padding: 12px 0; border-bottom: 1px solid rgba(139, 92, 246, 0.2);">
                                                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                                <tr>
                                                                    <td style="color: #6b21a8; font-size: 14px; font-weight: 500; width: 45%;">Organization Type</td>
                                                                    <td style="color: #7c3aed; font-size: 14px; font-weight: 600; text-align: right;">${organization.organizationType.replace("_", " ")}</td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="padding: 12px 0; border-bottom: 1px solid rgba(139, 92, 246, 0.2);">
                                                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                                <tr>
                                                                    <td style="color: #6b21a8; font-size: 14px; font-weight: 500; width: 45%;">License Number</td>
                                                                    <td style="color: #7c3aed; font-size: 14px; font-weight: 600; text-align: right;">${organization.licenseNumber}</td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="padding: 12px 0; border-bottom: 1px solid rgba(139, 92, 246, 0.2);">
                                                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                                <tr>
                                                                    <td style="color: #6b21a8; font-size: 14px; font-weight: 500; width: 45%;">Location</td>
                                                                    <td style="color: #7c3aed; font-size: 14px; font-weight: 600; text-align: right;">${organization.city}, ${organization.state}</td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="padding: 12px 0;">
                                                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                                <tr>
                                                                    <td style="color: #6b21a8; font-size: 14px; font-weight: 500; width: 45%;">Email</td>
                                                                    <td style="color: #7c3aed; font-size: 14px; font-weight: 600; text-align: right;">${organization.email}</td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </td>
                                    </tr>

                                    <!-- What's Next Section -->
                                    <tr>
                                        <td style="padding: 0 40px 32px 40px;">
                                            <h3 style="margin: 0 0 24px 0; color: #1f2937; font-size: 20px; font-weight: 600;">What Happens Next?</h3>
                                            
                                            <!-- Step 1 -->
                                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-bottom: 20px;">
                                                <tr>
                                                    <td style="width: 48px; vertical-align: top; padding-top: 2px;">
                                                        <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%); border-radius: 10px; text-align: center; line-height: 40px; font-size: 18px; font-weight: 700; color: #1e40af;">
                                                            1
                                                        </div>
                                                    </td>
                                                    <td style="padding-left: 16px;">
                                                        <h4 style="margin: 0 0 6px 0; color: #1f2937; font-size: 16px; font-weight: 600;">Document Review</h4>
                                                        <p style="margin: 0; color: #6b7280; font-size: 14px; line-height: 1.5;">Our admin team will thoroughly review your submitted documents and verify your credentials.</p>
                                                    </td>
                                                </tr>
                                            </table>

                                            <!-- Step 2 -->
                                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-bottom: 20px;">
                                                <tr>
                                                    <td style="width: 48px; vertical-align: top; padding-top: 2px;">
                                                        <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%); border-radius: 10px; text-align: center; line-height: 40px; font-size: 18px; font-weight: 700; color: #1e40af;">
                                                            2
                                                        </div>
                                                    </td>
                                                    <td style="padding-left: 16px;">
                                                        <h4 style="margin: 0 0 6px 0; color: #1f2937; font-size: 16px; font-weight: 600;">Email Notification</h4>
                                                        <p style="margin: 0; color: #6b7280; font-size: 14px; line-height: 1.5;">You'll receive an email once verification is complete with further instructions.</p>
                                                    </td>
                                                </tr>
                                            </table>

                                            <!-- Step 3 -->
                                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                <tr>
                                                    <td style="width: 48px; vertical-align: top; padding-top: 2px;">
                                                        <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%); border-radius: 10px; text-align: center; line-height: 40px; font-size: 18px; font-weight: 700; color: #1e40af;">
                                                            3
                                                        </div>
                                                    </td>
                                                    <td style="padding-left: 16px;">
                                                        <h4 style="margin: 0 0 6px 0; color: #1f2937; font-size: 16px; font-weight: 600;">Start Posting Requests</h4>
                                                        <p style="margin: 0; color: #6b7280; font-size: 14px; line-height: 1.5;">After approval, you can login and start posting blood donation requests immediately.</p>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>

                                    <!-- Closing Message -->
                                    <tr>
                                        <td style="padding: 0 40px 40px 40px;">
                                            <div style="background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%); border-radius: 10px; padding: 24px; text-align: center; border: 1px solid #a7f3d0;">
                                                <p style="margin: 0; color: #065f46; font-size: 16px; font-weight: 600; line-height: 1.6;">
                                                    ✅ We'll notify you as soon as your account is verified!
                                                </p>
                                            </div>
                                        </td>
                                    </tr>

                                    <!-- Divider -->
                                    <tr>
                                        <td style="padding: 0 40px;">
                                            <div style="border-top: 2px solid #f3f4f6;"></div>
                                        </td>
                                    </tr>

                                    <!-- Footer -->
                                    <tr>
                                        <td style="padding: 32px 40px; border-top: 1px solid #e5e7eb;">
                                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                <tr>
                                                    <td style="text-align: center;">
                                                        <p style="margin: 0 0 8px 0; color: #1f2937; font-size: 16px; font-weight: 600;">BloodDonate</p>
                                                        <p style="margin: 0 0 16px 0; color: #9ca3af; font-size: 13px; line-height: 1.6;">© ${new Date().getFullYear()} BloodDonate. All rights reserved.</p>
                                                        <p style="margin: 0 0 12px 0; color: #9ca3af; font-size: 12px; line-height: 1.6;">This is an automated email. Please do not reply.</p>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>

                                </table>
                            </td>
                        </tr>
                    </table>
                </body>
                </html>
 `;
		return await this.sendEmail({ to: organization.email, subject, html });
	}

	// verified email after organization register
	async sendOrganizationApprovedEmail(organization) {
		const subject = "Your Organization Has Been Verified!";
		const html = `
                <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Verification Approved - BloodDonate</title>
            </head>
            <body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #f5f5f5;">
                <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f5f5f5;">
                    <tr>
                        <td style="padding: 40px 20px;">
                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.07);">
                                
                                <!-- Header with gradient -->
                                <tr>
                                    <td style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 48px 40px; text-align: center;">
                                        <div style="background-color: rgba(255, 255, 255, 0.2); width: 80px; height: 80px; border-radius: 50%; margin: 0 auto 24px; line-height: 80px; font-size: 40px;">
                                            ✅
                                        </div>
                                        <h1 style="margin: 0 0 12px 0; color: #ffffff; font-size: 32px; font-weight: 700; letter-spacing: -0.5px;">Verification Approved!</h1>
                                        <p style="margin: 0; color: rgba(255, 255, 255, 0.95); font-size: 16px; line-height: 1.5;">Welcome to the BloodDonate Network</p>
                                    </td>
                                </tr>

                                <!-- Greeting Section -->
                                <tr>
                                    <td style="padding: 40px 40px 32px 40px;">
                                        <h2 style="margin: 0 0 16px 0; color: #1f2937; font-size: 24px; font-weight: 600;">Dear ${organization.organizationName},</h2>
                                        <p style="margin: 0; color: #6b7280; font-size: 16px; line-height: 1.6;">We're thrilled to inform you that your organization has been successfully verified by our admin team. You're now part of our life-saving network!</p>
                                    </td>
                                </tr>

                                <!-- Success Box -->
                                <tr>
                                    <td style="padding: 0 40px 32px 40px;">
                                        <div style="background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%); border-left: 4px solid #10b981; border-radius: 8px; padding: 24px;">
                                            <h3 style="margin: 0 0 12px 0; color: #065f46; font-size: 18px; font-weight: 600;">
                                                🎉 Congratulations!
                                            </h3>
                                            <p style="margin: 0; color: #047857; font-size: 15px; line-height: 1.6;">Your organization has been successfully verified and you can now access all platform features!</p>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Features Section -->
                                <tr>
                                    <td style="padding: 0 40px 32px 40px;">
                                        <h3 style="margin: 0 0 24px 0; color: #1f2937; font-size: 20px; font-weight: 600;">What You Can Do Now</h3>
                                        
                                        <!-- Feature 1 -->
                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-bottom: 16px;">
                                            <tr>
                                                <td style="width: 48px; vertical-align: top; padding-top: 2px;">
                                                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%); border-radius: 10px; text-align: center; line-height: 40px; font-size: 20px;">
                                                        🔓
                                                    </div>
                                                </td>
                                                <td style="padding-left: 16px;">
                                                    <h4 style="margin: 0 0 6px 0; color: #1f2937; font-size: 16px; font-weight: 600;">Access Your Dashboard</h4>
                                                    <p style="margin: 0; color: #6b7280; font-size: 14px; line-height: 1.5;">Login and explore your personalized organization dashboard.</p>
                                                </td>
                                            </tr>
                                        </table>

                                        <!-- Feature 2 -->
                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-bottom: 16px;">
                                            <tr>
                                                <td style="width: 48px; vertical-align: top; padding-top: 2px;">
                                                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); border-radius: 10px; text-align: center; line-height: 40px; font-size: 20px;">
                                                        📝
                                                    </div>
                                                </td>
                                                <td style="padding-left: 16px;">
                                                    <h4 style="margin: 0 0 6px 0; color: #1f2937; font-size: 16px; font-weight: 600;">Post Blood Requests</h4>
                                                    <p style="margin: 0; color: #6b7280; font-size: 14px; line-height: 1.5;">Create urgent blood requests and reach verified donors instantly.</p>
                                                </td>
                                            </tr>
                                        </table>

                                        <!-- Feature 3 -->
                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-bottom: 16px;">
                                            <tr>
                                                <td style="width: 48px; vertical-align: top; padding-top: 2px;">
                                                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #fecaca 0%, #fca5a5 100%); border-radius: 10px; text-align: center; line-height: 40px; font-size: 20px;">
                                                        💉
                                                    </div>
                                                </td>
                                                <td style="padding-left: 16px;">
                                                    <h4 style="margin: 0 0 6px 0; color: #1f2937; font-size: 16px; font-weight: 600;">Record Donations</h4>
                                                    <p style="margin: 0; color: #6b7280; font-size: 14px; line-height: 1.5;">Track and manage all blood donations efficiently.</p>
                                                </td>
                                            </tr>
                                        </table>

                                        <!-- Feature 4 -->
                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-bottom: 16px;">
                                            <tr>
                                                <td style="width: 48px; vertical-align: top; padding-top: 2px;">
                                                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #e9d5ff 0%, #d8b4fe 100%); border-radius: 10px; text-align: center; line-height: 40px; font-size: 20px;">
                                                        📊
                                                    </div>
                                                </td>
                                                <td style="padding-left: 16px;">
                                                    <h4 style="margin: 0 0 6px 0; color: #1f2937; font-size: 16px; font-weight: 600;">View Analytics</h4>
                                                    <p style="margin: 0; color: #6b7280; font-size: 14px; line-height: 1.5;">Access comprehensive donation records and insightful analytics.</p>
                                                </td>
                                            </tr>
                                        </table>

                                        <!-- Feature 5 -->
                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                            <tr>
                                                <td style="width: 48px; vertical-align: top; padding-top: 2px;">
                                                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%); border-radius: 10px; text-align: center; line-height: 40px; font-size: 20px;">
                                                        👥
                                                    </div>
                                                </td>
                                                <td style="padding-left: 16px;">
                                                    <h4 style="margin: 0 0 6px 0; color: #1f2937; font-size: 16px; font-weight: 600;">Connect With Donors</h4>
                                                    <p style="margin: 0; color: #6b7280; font-size: 14px; line-height: 1.5;">Find and connect with verified donors in your area.</p>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>


                                <!-- Divider -->
                                <tr>
                                    <td style="padding: 0 40px;">
                                        <div style="border-top: 2px solid #f3f4f6;"></div>
                                    </td>
                                </tr>

                                <!-- Thank You Message -->
                                <tr>
                                    <td style="padding: 32px 40px;">
                                        <div style="background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%); border-radius: 10px; padding: 24px; text-align: center; border: 1px solid #fecaca;">
                                            <p style="margin: 0; color: #991b1b; font-size: 16px; font-weight: 600; line-height: 1.6;">
                                                🩸 Thank you for joining our mission to save lives!
                                            </p>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Footer -->
                                <tr>
                                    <td style="padding: 32px 40px; border-top: 1px solid #e5e7eb;">
                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                            <tr>
                                                <td style="text-align: center;">
                                                    <p style="margin: 0 0 8px 0; color: #1f2937; font-size: 16px; font-weight: 600;">BloodDonate</p>
                                                    <p style="margin: 0 0 16px 0; color: #9ca3af; font-size: 13px; line-height: 1.6;">© ${new Date().getFullYear()} BloodDonate. All rights reserved.</p>
                                                    <p style="margin: 0 0 12px 0; color: #9ca3af; font-size: 12px; line-height: 1.6;">This is an automated email. Please do not reply.</p>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>

                            </table>
                        </td>
                    </tr>
                </table>
            </body>
            </html>
            `;
		return await this.sendEmail({ to: organization.email, subject, html });
	}

	// new blood request alert email for mathing donors
	async sendBloodRequestAlert(donor, bloodRequest, organization) {
		const subject = `URGENT: ${bloodRequest.bloodType} Blood Needed in ${bloodRequest.city}`;
		const html = `
        <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Urgent Blood Request - BloodDonate</title>
                </head>
                <body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #f5f5f5;">
                    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f5f5f5;">
                        <tr>
                            <td style="padding: 40px 20px;">
                                <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.07);">
                                    
                                    <!-- Header with gradient -->
                                    <tr>
                                        <td style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); padding: 48px 40px; text-align: center;">
                                            <div style="background-color: rgba(255, 255, 255, 0.2); width: 80px; height: 80px; border-radius: 50%; margin: 0 auto 24px; line-height: 80px; font-size: 40px;">
                                                🚨
                                            </div>
                                            <h1 style="margin: 0 0 12px 0; color: #ffffff; font-size: 32px; font-weight: 700; letter-spacing: -0.5px;">Urgent Blood Request</h1>
                                            <p style="margin: 0; color: rgba(255, 255, 255, 0.95); font-size: 18px; line-height: 1.5; font-weight: 600;">Your blood type is needed!</p>
                                        </td>
                                    </tr>

                                    <!-- Greeting Section -->
                                    <tr>
                                        <td style="padding: 40px 40px 32px 40px;">
                                            <h2 style="margin: 0 0 16px 0; color: #1f2937; font-size: 24px; font-weight: 600;">Dear ${donor.name},</h2>
                                            <p style="margin: 0; color: #6b7280; font-size: 16px; line-height: 1.6;">A patient in your area urgently needs your blood type. Your contribution could save a life today.</p>
                                        </td>
                                    </tr>

                                    <!-- Urgency Alert Box -->
                                    <tr>
                                        <td style="padding: 0 40px 32px 40px;">
                                            <div style="background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%); border: 3px solid #ef4444; border-radius: 12px; padding: 24px; text-align: center;">
                                                <h3 style="margin: 0 0 12px 0; color: #991b1b; font-size: 24px; font-weight: 700;">
                                                    ${bloodRequest.urgency === "critical" ? "🔴 CRITICAL" : bloodRequest.urgency === "high" ? "🟠 HIGH" : bloodRequest.urgency === "medium" ? "🟡 MEDIUM" : "🟢 LOW"} URGENCY
                                                </h3>
                                                <p style="margin: 0; color: #7f1d1d; font-size: 18px; font-weight: 600; line-height: 1.6;">
                                                    <strong style="font-size: 22px; color: #dc2626;">${bloodRequest.bloodType}</strong> blood is urgently needed!
                                                </p>
                                            </div>
                                        </td>
                                    </tr>

                                    <!-- Patient Information Card -->
                                    <tr>
                                        <td style="padding: 0 40px 32px 40px;">
                                            <h3 style="margin: 0 0 20px 0; color: #1f2937; font-size: 20px; font-weight: 600;">Patient Information</h3>
                                            
                                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                <tr>
                                                    <!-- Left Column -->
                                                    <td style="width: 48%; vertical-align: top; padding-right: 8px;">
                                                        <!-- Blood Type -->
                                                        <div style="background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%); border-left: 4px solid #ef4444; border-radius: 8px; padding: 16px; margin-bottom: 12px;">
                                                            <p style="margin: 0 0 4px 0; color: #7f1d1d; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Blood Type</p>
                                                            <p style="margin: 0; color: #dc2626; font-size: 20px; font-weight: 700;">${bloodRequest.bloodType}</p>
                                                        </div>
                                                        
                                                        <!-- Patient Info -->
                                                        <div style="background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%); border-left: 4px solid #ef4444; border-radius: 8px; padding: 16px;">
                                                            <p style="margin: 0 0 4px 0; color: #7f1d1d; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Patient</p>
                                                            <p style="margin: 0; color: #991b1b; font-size: 15px; font-weight: 600;">${bloodRequest.patientName}, ${bloodRequest.patientAge} years</p>
                                                        </div>
                                                    </td>
                                                    
                                                    <!-- Right Column -->
                                                    <td style="width: 48%; vertical-align: top; padding-left: 8px;">
                                                        <!-- Units Needed -->
                                                        <div style="background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%); border-left: 4px solid #ef4444; border-radius: 8px; padding: 16px; margin-bottom: 12px;">
                                                            <p style="margin: 0 0 4px 0; color: #7f1d1d; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Units Needed</p>
                                                            <p style="margin: 0; color: #dc2626; font-size: 20px; font-weight: 700;">${bloodRequest.unitsNeeded}</p>
                                                        </div>
                                                        
                                                        <!-- Required By -->
                                                        <div style="background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%); border-left: 4px solid #ef4444; border-radius: 8px; padding: 16px;">
                                                            <p style="margin: 0 0 4px 0; color: #7f1d1d; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Required By</p>
                                                            <p style="margin: 0; color: #991b1b; font-size: 14px; font-weight: 600;">${new Date(bloodRequest.requiredBy).toLocaleString()}</p>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>

                                    <!-- Hospital Details Card -->
                                    <tr>
                                        <td style="padding: 0 40px 32px 40px;">
                                            <h3 style="margin: 0 0 20px 0; color: #1f2937; font-size: 20px; font-weight: 600;">Hospital Details</h3>
                                            <div style="background: linear-gradient(135deg, #f3e8ff 0%, #e9d5ff 100%); border-left: 4px solid #8b5cf6; border-radius: 12px; padding: 24px;">
                                                <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                    <tr>
                                                        <td style="padding-bottom: 12px;">
                                                            <p style="margin: 0 0 4px 0; color: #6b21a8; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Hospital Name</p>
                                                            <p style="margin: 0; color: #7c3aed; font-size: 16px; font-weight: 600;">${organization.organizationName}</p>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="padding-bottom: 12px;">
                                                            <p style="margin: 0 0 4px 0; color: #6b21a8; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Location</p>
                                                            <p style="margin: 0; color: #7c3aed; font-size: 15px; font-weight: 500;">${organization.address}, ${organization.city}</p>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <p style="margin: 0 0 4px 0; color: #6b21a8; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Contact Number</p>
                                                            <p style="margin: 0; color: #7c3aed; font-size: 16px; font-weight: 600;">${bloodRequest.contactNumber}</p>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </td>
                                    </tr>

                                    <!-- Additional Details -->
                                    <tr>
                                        <td style="padding: 0 40px 32px 40px;">
                                            <div style="background: #f9fafb; border-radius: 8px; padding: 20px; border: 1px solid #e5e7eb;">
                                                <p style="margin: 0 0 12px 0;">
                                                    <strong style="color: #1f2937; font-size: 14px;">Reason:</strong><br>
                                                    <span style="color: #6b7280; font-size: 15px; line-height: 1.6;">${bloodRequest.reason}</span>
                                                </p>
                                                ${
																									bloodRequest.notes
																										? `<p style="margin: 0;">
                                                    <strong style="color: #1f2937; font-size: 14px;">Additional Notes:</strong><br>
                                                    <span style="color: #6b7280; font-size: 15px; line-height: 1.6;">${bloodRequest.notes}</span>
                                                </p>`
																										: ""
																								}
                                            </div>
                                        </td>
                                    </tr>

                                    <!-- Info Notice -->
                                    <tr>
                                        <td style="padding: 0 40px 32px 40px;">
                                            <div style="background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%); border-radius: 8px; padding: 20px; border-left: 4px solid #3b82f6;">
                                                <p style="margin: 0; color: #1e40af; font-size: 14px; line-height: 1.6;">
                                                    ℹ️ You're receiving this email because your blood type (<strong>${donor.bloodType}</strong>) matches this urgent request and you're marked as available.
                                                </p>
                                            </div>
                                        </td>
                                    </tr>

                                    <!-- Divider -->
                                    <tr>
                                        <td style="padding: 0 40px;">
                                            <div style="border-top: 2px solid #f3f4f6;"></div>
                                        </td>
                                    </tr>


                                    <!-- Footer -->
                                    <tr>
                                        <td style="padding: 32px 40px; border-top: 1px solid #e5e7eb;">
                                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                <tr>
                                                    <td style="text-align: center;">
                                                        <p style="margin: 0 0 8px 0; color: #1f2937; font-size: 16px; font-weight: 600;">BloodDonate</p>
                                                        <p style="margin: 0 0 16px 0; color: #9ca3af; font-size: 13px; line-height: 1.6;">© ${new Date().getFullYear()} BloodDonate. All rights reserved.</p>
                                                        <p style="margin: 0 0 12px 0; color: #9ca3af; font-size: 12px; line-height: 1.6;">This is an automated urgent notification.</p>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>

                                </table>
                            </td>
                        </tr>
                    </table>
                </body>
            </html>
`;
		return await this.sendEmail({ to: donor.email, subject, html });
	}

	// donation recorded confirmation email to donors
	async sendDonationConfirmationEmail(donor, donation, organization) {
		const subject = `Thank You for Your Blood Donation!`;
		const html = `
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Donation Confirmation - BloodDonate</title>
        </head>
        <body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #f5f5f5;">
            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f5f5f5;">
                <tr>
                    <td style="padding: 40px 20px;">
                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.07);">
                            
                            <!-- Header with gradient -->
                            <tr>
                                <td style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 48px 40px; text-align: center;">
                                    <div style="background-color: rgba(255, 255, 255, 0.2); width: 80px; height: 80px; border-radius: 50%; margin: 0 auto 24px; line-height: 80px; font-size: 40px;">
                                        🎉
                                    </div>
                                    <h1 style="margin: 0 0 12px 0; color: #ffffff; font-size: 32px; font-weight: 700; letter-spacing: -0.5px;">Thank You, Hero!</h1>
                                    <p style="margin: 0; color: rgba(255, 255, 255, 0.95); font-size: 16px; line-height: 1.5;">Your donation has been recorded</p>
                                </td>
                            </tr>

                            <!-- Greeting Section -->
                            <tr>
                                <td style="padding: 40px 40px 32px 40px;">
                                    <h2 style="margin: 0 0 16px 0; color: #1f2937; font-size: 24px; font-weight: 600;">Dear ${donor.name},</h2>
                                    <p style="margin: 0; color: #6b7280; font-size: 16px; line-height: 1.6;">Thank you for your incredible generosity. Your blood donation is a true gift of life.</p>
                                </td>
                            </tr>

                            <!-- Success Box -->
                            <tr>
                                <td style="padding: 0 40px 32px 40px;">
                                    <div style="background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%); border-left: 4px solid #10b981; border-radius: 12px; padding: 28px; text-align: center;">
                                        <h3 style="margin: 0 0 12px 0; color: #065f46; font-size: 22px; font-weight: 700;">
                                            ✅ Your donation has been recorded!
                                        </h3>
                                        <p style="margin: 0; color: #047857; font-size: 18px; font-weight: 600; line-height: 1.6;">
                                            You've just helped save up to <strong style="font-size: 24px; color: #059669;">3 lives!</strong> 🩸
                                        </p>
                                    </div>
                                </td>
                            </tr>

                            <!-- Donation Details Card -->
                            <tr>
                                <td style="padding: 0 40px 32px 40px;">
                                    <h3 style="margin: 0 0 20px 0; color: #1f2937; font-size: 20px; font-weight: 600;">Donation Details</h3>
                                    <div style="background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%); border-left: 4px solid #10b981; border-radius: 12px; padding: 24px;">
                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                            <tr>
                                                <td style="padding-bottom: 12px;">
                                                    <p style="margin: 0 0 4px 0; color: #065f46; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Donation Date</p>
                                                    <p style="margin: 0; color: #059669; font-size: 16px; font-weight: 600;">${new Date(donation.donationDate).toLocaleDateString("en-US", {
																											weekday: "long",
																											year: "numeric",
																											month: "long",
																											day: "numeric",
																										})}</p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding-bottom: 12px;">
                                                    <p style="margin: 0 0 4px 0; color: #065f46; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Blood Type</p>
                                                    <p style="margin: 0; color: #059669; font-size: 18px; font-weight: 700;">${donation.bloodType}</p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding-bottom: 12px;">
                                                    <p style="margin: 0 0 4px 0; color: #065f46; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Units Donated</p>
                                                    <p style="margin: 0; color: #059669; font-size: 18px; font-weight: 700;">${donation.unitsCollected}</p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <p style="margin: 0 0 4px 0; color: #065f46; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Location</p>
                                                    <p style="margin: 0; color: #059669; font-size: 15px; font-weight: 600;">${organization.organizationName}, ${organization.city}</p>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                </td>
                            </tr>

                            <!-- Your Impact Stats -->
                            <tr>
                                <td style="padding: 0 40px 32px 40px;">
                                    <h3 style="margin: 0 0 20px 0; color: #1f2937; font-size: 20px; font-weight: 600;">Your Impact</h3>
                                    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                        <tr>
                                            <!-- Total Donations -->
                                            <td style="width: 48%; vertical-align: top; padding-right: 8px;">
                                                <div style="background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%); border-radius: 12px; padding: 24px; text-align: center; border: 1px solid #fecaca;">
                                                    <p style="margin: 0 0 8px 0; color: #dc2626; font-size: 40px; font-weight: 800; line-height: 1;">${donor.totalDonations + 1}</p>
                                                    <p style="margin: 0; color: #991b1b; font-size: 14px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Total Donations</p>
                                                </div>
                                            </td>
                                            
                                            <!-- Lives Saved -->
                                            <td style="width: 48%; vertical-align: top; padding-left: 8px;">
                                                <div style="background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%); border-radius: 12px; padding: 24px; text-align: center; border: 1px solid #6ee7b7;">
                                                    <p style="margin: 0 0 8px 0; color: #10b981; font-size: 40px; font-weight: 800; line-height: 1;">${(donor.totalDonations + 1) * 3}</p>
                                                    <p style="margin: 0; color: #065f46; font-size: 14px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Lives Saved</p>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>

                            <!-- Important Reminders -->
                            <tr>
                                <td style="padding: 0 40px 32px 40px;">
                                    <h3 style="margin: 0 0 20px 0; color: #1f2937; font-size: 20px; font-weight: 600;">Important Reminders</h3>
                                    
                                    <!-- Reminder 1 -->
                                    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-bottom: 12px;">
                                        <tr>
                                            <td style="width: 40px; vertical-align: top; padding-top: 2px;">
                                                <div style="width: 32px; height: 32px; background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%); border-radius: 8px; text-align: center; line-height: 32px; font-size: 16px;">
                                                    🥤
                                                </div>
                                            </td>
                                            <td style="padding-left: 12px;">
                                                <p style="margin: 0; color: #1f2937; font-size: 15px; line-height: 1.5;">Drink plenty of fluids in the next 24 hours</p>
                                            </td>
                                        </tr>
                                    </table>

                                    <!-- Reminder 2 -->
                                    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-bottom: 12px;">
                                        <tr>
                                            <td style="width: 40px; vertical-align: top; padding-top: 2px;">
                                                <div style="width: 32px; height: 32px; background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); border-radius: 8px; text-align: center; line-height: 32px; font-size: 16px;">
                                                    🍽️
                                                </div>
                                            </td>
                                            <td style="padding-left: 12px;">
                                                <p style="margin: 0; color: #1f2937; font-size: 15px; line-height: 1.5;">Eat iron-rich foods to replenish your blood</p>
                                            </td>
                                        </tr>
                                    </table>

                                    <!-- Reminder 3 -->
                                    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-bottom: 12px;">
                                        <tr>
                                            <td style="width: 40px; vertical-align: top; padding-top: 2px;">
                                                <div style="width: 32px; height: 32px; background: linear-gradient(135deg, #e9d5ff 0%, #d8b4fe 100%); border-radius: 8px; text-align: center; line-height: 32px; font-size: 16px;">
                                                    😴
                                                </div>
                                            </td>
                                            <td style="padding-left: 12px;">
                                                <p style="margin: 0; color: #1f2937; font-size: 15px; line-height: 1.5;">Get adequate rest today</p>
                                            </td>
                                        </tr>
                                    </table>

                                    <!-- Reminder 4 -->
                                    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-bottom: 12px;">
                                        <tr>
                                            <td style="width: 40px; vertical-align: top; padding-top: 2px;">
                                                <div style="width: 32px; height: 32px; background: linear-gradient(135deg, #fecaca 0%, #fca5a5 100%); border-radius: 8px; text-align: center; line-height: 32px; font-size: 16px;">
                                                    💪
                                                </div>
                                            </td>
                                            <td style="padding-left: 12px;">
                                                <p style="margin: 0; color: #1f2937; font-size: 15px; line-height: 1.5;">Avoid strenuous activity for 24 hours</p>
                                            </td>
                                        </tr>
                                    </table>

                                    <!-- Reminder 5 -->
                                    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                        <tr>
                                            <td style="width: 40px; vertical-align: top; padding-top: 2px;">
                                                <div style="width: 32px; height: 32px; background: linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%); border-radius: 8px; text-align: center; line-height: 32px; font-size: 16px;">
                                                    📅
                                                </div>
                                            </td>
                                            <td style="padding-left: 12px;">
                                                <p style="margin: 0; color: #1f2937; font-size: 15px; line-height: 1.5;">You can donate again after <strong style="color: #10b981;">${new Date(new Date(donation.donationDate).setDate(new Date(donation.donationDate).getDate() + 56)).toLocaleDateString("en-US", {
																									month: "long",
																									day: "numeric",
																									year: "numeric",
																								})}</strong></p>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>

                            <!-- Thank You Message -->
                            <tr>
                                <td style="padding: 0 40px 40px 40px;">
                                    <div style="background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%); border-radius: 10px; padding: 28px; text-align: center; border: 1px solid #6ee7b7;">
                                        <p style="margin: 0; color: #065f46; font-size: 18px; font-weight: 700; line-height: 1.6;">
                                            Thank you for being a life-saver!<br>
                                            <span style="font-size: 16px; font-weight: 600; color: #047857;">Your generosity makes a real difference. 🙏</span>
                                        </p>
                                    </div>
                                </td>
                            </tr>

                            <!-- Divider -->
                            <tr>
                                <td style="padding: 0 40px;">
                                    <div style="border-top: 2px solid #f3f4f6;"></div>
                                </td>
                            </tr>

                            <!-- Next Donation Info -->
                            <tr>
                                <td style="padding: 32px 40px;">
                                    <div style="background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%); border-radius: 8px; padding: 20px; border-left: 4px solid #3b82f6;">
                                        <p style="margin: 0; color: #1e40af; font-size: 14px; line-height: 1.6;">
                                            💡 <strong>Did you know?</strong> You can save even more lives by scheduling your next donation in advance. We'll send you a reminder when you're eligible to donate again.
                                        </p>
                                    </div>
                                </td>
                            </tr>

                            <!-- Footer -->
                            <tr>
                                <td style="padding: 32px 40px; border-top: 1px solid #e5e7eb;">
                                    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                        <tr>
                                            <td style="text-align: center;">
                                                <p style="margin: 0 0 8px 0; color: #1f2937; font-size: 16px; font-weight: 600;">BloodDonate</p>
                                                <p style="margin: 0 0 16px 0; color: #9ca3af; font-size: 13px; line-height: 1.6;">© ${new Date().getFullYear()} BloodDonate. All rights reserved.</p>
                                                <p style="margin: 0 0 12px 0; color: #9ca3af; font-size: 12px; line-height: 1.6;">This is an automated confirmation email.</p>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>

                        </table>
                    </td>
                </tr>
            </table>
        </body>
        </html>
        `;
		return await this.sendEmail({ to: donor.email, subject, html });
	}

	// blood request fulfilled email to organizations
	async sendRequestFulfilledEmail(organization, bloodRequest, donor) {
		const subject = `Blood Request Fulfilled - ${bloodRequest.patientName}`;
		const html = `
          <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Request Fulfilled - BloodDonate</title>
            </head>
            <body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #f5f5f5;">
                <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f5f5f5;">
                    <tr>
                        <td style="padding: 40px 20px;">
                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.07);">
                                
                                <!-- Header with gradient -->
                                <tr>
                                    <td style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 48px 40px; text-align: center;">
                                        <div style="background-color: rgba(255, 255, 255, 0.2); width: 80px; height: 80px; border-radius: 50%; margin: 0 auto 24px; line-height: 80px; font-size: 40px;">
                                            ✅
                                        </div>
                                        <h1 style="margin: 0 0 12px 0; color: #ffffff; font-size: 32px; font-weight: 700; letter-spacing: -0.5px;">Request Fulfilled!</h1>
                                        <p style="margin: 0; color: rgba(255, 255, 255, 0.95); font-size: 16px; line-height: 1.5;">A life has been saved through your request</p>
                                    </td>
                                </tr>

                                <!-- Greeting Section -->
                                <tr>
                                    <td style="padding: 40px 40px 32px 40px;">
                                        <h2 style="margin: 0 0 16px 0; color: #1f2937; font-size: 24px; font-weight: 600;">Dear ${organization.organizationName},</h2>
                                        <p style="margin: 0; color: #6b7280; font-size: 16px; line-height: 1.6;">Great news! Your blood request has been successfully fulfilled. A generous donor has answered the call to save a life.</p>
                                    </td>
                                </tr>

                                <!-- Success Box -->
                                <tr>
                                    <td style="padding: 0 40px 32px 40px;">
                                        <div style="background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%); border-left: 4px solid #10b981; border-radius: 12px; padding: 24px; text-align: center;">
                                            <h3 style="margin: 0 0 8px 0; color: #065f46; font-size: 20px; font-weight: 700;">
                                                🎉 Mission Accomplished!
                                            </h3>
                                            <p style="margin: 0; color: #047857; font-size: 16px; line-height: 1.6;">
                                                The blood request for <strong style="color: #059669;">${bloodRequest.patientName}</strong> has been successfully fulfilled!
                                            </p>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Request Details Card -->
                                <tr>
                                    <td style="padding: 0 40px 32px 40px;">
                                        <h3 style="margin: 0 0 20px 0; color: #1f2937; font-size: 20px; font-weight: 600;">Request Details</h3>
                                        <div style="background: linear-gradient(135deg, #f3e8ff 0%, #e9d5ff 100%); border-radius: 12px; padding: 28px; border: 1px solid #d8b4fe;">
                                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                <tr>
                                                    <td style="padding: 12px 0; border-bottom: 1px solid rgba(139, 92, 246, 0.2);">
                                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                            <tr>
                                                                <td style="color: #6b21a8; font-size: 14px; font-weight: 500; width: 35%;">Patient</td>
                                                                <td style="color: #7c3aed; font-size: 15px; font-weight: 600; text-align: right;">${bloodRequest.patientName}, ${bloodRequest.patientAge} years</td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="padding: 12px 0; border-bottom: 1px solid rgba(139, 92, 246, 0.2);">
                                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                            <tr>
                                                                <td style="color: #6b21a8; font-size: 14px; font-weight: 500; width: 35%;">Blood Type</td>
                                                                <td style="color: #7c3aed; font-size: 18px; font-weight: 700; text-align: right;">${bloodRequest.bloodType}</td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="padding: 12px 0; border-bottom: 1px solid rgba(139, 92, 246, 0.2);">
                                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                            <tr>
                                                                <td style="color: #6b21a8; font-size: 14px; font-weight: 500; width: 35%;">Units Needed</td>
                                                                <td style="color: #7c3aed; font-size: 16px; font-weight: 600; text-align: right;">${bloodRequest.unitsNeeded}</td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="padding: 12px 0;">
                                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                            <tr>
                                                                <td style="color: #6b21a8; font-size: 14px; font-weight: 500; width: 35%;">Donor</td>
                                                                <td style="color: #7c3aed; font-size: 15px; font-weight: 600; text-align: right;">${donor.name}</td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </table>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Status Update Info -->
                                <tr>
                                    <td style="padding: 0 40px 32px 40px;">
                                        <div style="background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%); border-radius: 8px; padding: 20px; border-left: 4px solid #3b82f6;">
                                            <p style="margin: 0; color: #1e40af; font-size: 14px; line-height: 1.6;">
                                                ℹ️ This blood request has been automatically marked as <strong>fulfilled</strong> in the system. You can view the complete details in your dashboard.
                                            </p>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Donor Appreciation -->
                                <tr>
                                    <td style="padding: 0 40px 32px 40px;">
                                        <div style="background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%); border-radius: 10px; padding: 24px; text-align: center; border: 1px solid #fecaca;">
                                            <h3 style="margin: 0 0 8px 0; color: #991b1b; font-size: 18px; font-weight: 700;">
                                                🙏 Thanks to Our Hero Donor
                                            </h3>
                                            <p style="margin: 0; color: #7f1d1d; font-size: 15px; line-height: 1.6;">
                                                <strong>${donor.name}</strong> has made this life-saving donation possible. Together, we're making a difference!
                                            </p>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Divider -->
                                <tr>
                                    <td style="padding: 0 40px;">
                                        <div style="border-top: 2px solid #f3f4f6;"></div>
                                    </td>
                                </tr>

                                <!-- Thank You Message -->
                                <tr>
                                    <td style="padding: 32px 40px;">
                                        <div style="text-align: center;">
                                            <p style="margin: 0 0 8px 0; color: #10b981; font-size: 18px; font-weight: 700;">Thank you for using BloodDonate!</p>
                                            <p style="margin: 0; color: #6b7280; font-size: 15px; line-height: 1.6;">Together, we're building a network that saves lives every day. 🩸</p>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Quick Stats -->
                                <tr>
                                    <td style="padding: 0 40px 32px 40px;">
                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                            <tr>
                                                <td style="text-align: center; padding: 0 10px;">
                                                    <div style="font-size: 28px; font-weight: 700; color: #10b981; margin-bottom: 4px;">✅</div>
                                                    <div style="font-size: 12px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px;">Request Fulfilled</div>
                                                </td>
                                                <td style="text-align: center; padding: 0 10px; border-left: 1px solid #e5e7eb; border-right: 1px solid #e5e7eb;">
                                                    <div style="font-size: 28px; font-weight: 700; color: #10b981; margin-bottom: 4px;">🩸</div>
                                                    <div style="font-size: 12px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px;">Life Saved</div>
                                                </td>
                                                <td style="text-align: center; padding: 0 10px;">
                                                    <div style="font-size: 28px; font-weight: 700; color: #10b981; margin-bottom: 4px;">🎉</div>
                                                    <div style="font-size: 12px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px;">Mission Complete</div>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>

                                <!-- Footer -->
                                <tr>
                                    <td style="padding: 32px 40px; border-top: 1px solid #e5e7eb;">
                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                            <tr>
                                                <td style="text-align: center;">
                                                    <p style="margin: 0 0 8px 0; color: #1f2937; font-size: 16px; font-weight: 600;">BloodDonate</p>
                                                    <p style="margin: 0 0 16px 0; color: #9ca3af; font-size: 13px; line-height: 1.6;">© ${new Date().getFullYear()} BloodDonate. All rights reserved.</p>
                                                    <p style="margin: 0 0 12px 0; color: #9ca3af; font-size: 12px; line-height: 1.6;">This is an automated notification.</p>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>

                            </table>
                        </td>
                    </tr>
                </table>
            </body>
            </html>
        `;
		return await this.sendEmail({ to: organization.email, subject, html });
	}

	// 7. Weekly Donation Summary for Donors
	async sendWeeklySummaryEmail(donor, weeklyStats) {
		const subject = "📊 Your Weekly Donation Impact Summary";
		const html = `
    <!DOCTYPE html>
        <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Weekly Impact Summary - BloodDonate</title>
            </head>
            <body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #f5f5f5;">
                <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f5f5f5;">
                    <tr>
                        <td style="padding: 40px 20px;">
                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.07);">
                                
                                <!-- Header with gradient -->
                                <tr>
                                    <td style="background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); padding: 48px 40px; text-align: center;">
                                        <div style="background-color: rgba(255, 255, 255, 0.2); width: 80px; height: 80px; border-radius: 50%; margin: 0 auto 24px; line-height: 80px; font-size: 40px;">
                                            📊
                                        </div>
                                        <h1 style="margin: 0 0 12px 0; color: #ffffff; font-size: 32px; font-weight: 700; letter-spacing: -0.5px;">Your Weekly Impact</h1>
                                        <p style="margin: 0; color: rgba(255, 255, 255, 0.95); font-size: 16px; line-height: 1.5;">Blood donation activity in your area</p>
                                    </td>
                                </tr>

                                <!-- Greeting Section -->
                                <tr>
                                    <td style="padding: 40px 40px 32px 40px;">
                                        <h2 style="margin: 0 0 16px 0; color: #1f2937; font-size: 24px; font-weight: 600;">Hi ${donor.name},</h2>
                                        <p style="margin: 0; color: #6b7280; font-size: 16px; line-height: 1.6;">Here's a summary of blood donation activity in your area this week. Your participation makes a real difference in our community!</p>
                                    </td>
                                </tr>

                                <!-- Weekly Stats Section -->
                                <tr>
                                    <td style="padding: 0 40px 32px 40px;">
                                        <h3 style="margin: 0 0 24px 0; color: #1f2937; font-size: 20px; font-weight: 600;">This Week's Activity</h3>
                                        
                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                            <tr>
                                                <!-- New Requests -->
                                                <td style="width: 32%; vertical-align: top; padding-right: 8px;">
                                                    <div style="background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%); border-radius: 12px; padding: 24px; text-align: center; border: 1px solid #fecaca;">
                                                        <div style="margin-bottom: 8px; font-size: 28px;">🆕</div>
                                                        <p style="margin: 0 0 12px 0; color: #dc2626; font-size: 36px; font-weight: 800; line-height: 1;">${weeklyStats.newRequests}</p>
                                                        <p style="margin: 0; color: #991b1b; font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">New Requests</p>
                                                    </div>
                                                </td>
                                                
                                                <!-- Fulfilled -->
                                                <td style="width: 32%; vertical-align: top; padding: 0 4px;">
                                                    <div style="background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%); border-radius: 12px; padding: 24px; text-align: center; border: 1px solid #6ee7b7;">
                                                        <div style="margin-bottom: 8px; font-size: 28px;">✅</div>
                                                        <p style="margin: 0 0 12px 0; color: #10b981; font-size: 36px; font-weight: 800; line-height: 1;">${weeklyStats.fulfilled}</p>
                                                        <p style="margin: 0; color: #065f46; font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Fulfilled</p>
                                                    </div>
                                                </td>
                                                
                                                <!-- Active Donors -->
                                                <td style="width: 32%; vertical-align: top; padding-left: 8px;">
                                                    <div style="background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%); border-radius: 12px; padding: 24px; text-align: center; border: 1px solid #93c5fd;">
                                                        <div style="margin-bottom: 8px; font-size: 28px;">👥</div>
                                                        <p style="margin: 0 0 12px 0; color: #3b82f6; font-size: 36px; font-weight: 800; line-height: 1;">${weeklyStats.activeDonors}</p>
                                                        <p style="margin: 0; color: #1e40af; font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Active Donors</p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>

                                <!-- Impact Summary -->
                                <tr>
                                    <td style="padding: 0 40px 32px 40px;">
                                        <div style="background: linear-gradient(135deg, #f3e8ff 0%, #e9d5ff 100%); border-radius: 12px; padding: 28px; border: 1px solid #d8b4fe;">
                                            <h3 style="margin: 0 0 16px 0; color: #6b21a8; font-size: 18px; font-weight: 700; text-align: center;">
                                                🎯 Community Impact This Week
                                            </h3>
                                            <p style="margin: 0; color: #7c3aed; font-size: 15px; line-height: 1.6; text-align: center;">
                                                Together, our community has potentially saved <strong style="font-size: 20px; color: #6b21a8;">${weeklyStats.fulfilled * 3} lives</strong> through blood donations this week!
                                            </p>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Breakdown Section -->
                                <tr>
                                    <td style="padding: 0 40px 32px 40px;">
                                        <h3 style="margin: 0 0 20px 0; color: #1f2937; font-size: 20px; font-weight: 600;">Week at a Glance</h3>
                                        
                                        <!-- Stat Item 1 -->
                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-bottom: 16px;">
                                            <tr>
                                                <td style="width: 48px; vertical-align: top; padding-top: 2px;">
                                                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%); border-radius: 10px; text-align: center; line-height: 40px; font-size: 20px;">
                                                        📋
                                                    </div>
                                                </td>
                                                <td style="padding-left: 16px;">
                                                    <h4 style="margin: 0 0 4px 0; color: #1f2937; font-size: 16px; font-weight: 600;">Blood Requests</h4>
                                                    <p style="margin: 0; color: #6b7280; font-size: 14px; line-height: 1.5;"><strong style="color: #dc2626;">${weeklyStats.newRequests}</strong> new urgent requests were posted in your area</p>
                                                </td>
                                            </tr>
                                        </table>

                                        <!-- Stat Item 2 -->
                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-bottom: 16px;">
                                            <tr>
                                                <td style="width: 48px; vertical-align: top; padding-top: 2px;">
                                                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%); border-radius: 10px; text-align: center; line-height: 40px; font-size: 20px;">
                                                        💉
                                                    </div>
                                                </td>
                                                <td style="padding-left: 16px;">
                                                    <h4 style="margin: 0 0 4px 0; color: #1f2937; font-size: 16px; font-weight: 600;">Successful Donations</h4>
                                                    <p style="margin: 0; color: #6b7280; font-size: 14px; line-height: 1.5;"><strong style="color: #10b981;">${weeklyStats.fulfilled}</strong> requests were successfully fulfilled by generous donors</p>
                                                </td>
                                            </tr>
                                        </table>

                                        <!-- Stat Item 3 -->
                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                            <tr>
                                                <td style="width: 48px; vertical-align: top; padding-top: 2px;">
                                                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%); border-radius: 10px; text-align: center; line-height: 40px; font-size: 20px;">
                                                        🦸
                                                    </div>
                                                </td>
                                                <td style="padding-left: 16px;">
                                                    <h4 style="margin: 0 0 4px 0; color: #1f2937; font-size: 16px; font-weight: 600;">Community Heroes</h4>
                                                    <p style="margin: 0; color: #6b7280; font-size: 14px; line-height: 1.5;"><strong style="color: #3b82f6;">${weeklyStats.activeDonors}</strong> donors like you were active this week</p>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>

                                <!-- Divider -->
                                <tr>
                                    <td style="padding: 0 40px;">
                                        <div style="border-top: 2px solid #f3f4f6;"></div>
                                    </td>
                                </tr>

                                <!-- Thank You Message -->
                                <tr>
                                    <td style="padding: 32px 40px;">
                                        <div style="text-align: center;">
                                            <p style="margin: 0 0 8px 0; color: #3b82f6; font-size: 18px; font-weight: 700;">Thank you for being part of this life-saving community!</p>
                                            <p style="margin: 0; color: #6b7280; font-size: 15px; line-height: 1.6;">Every alert you respond to, every donation you make - it all adds up to save lives. 🩸</p>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Footer -->
                                <tr>
                                    <td style="padding: 32px 40px; border-top: 1px solid #e5e7eb;">
                                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                                            <tr>
                                                <td style="text-align: center;">
                                                    <p style="margin: 0 0 8px 0; color: #1f2937; font-size: 16px; font-weight: 600;">BloodDonate</p>
                                                    <p style="margin: 0 0 16px 0; color: #9ca3af; font-size: 13px; line-height: 1.6;">© ${new Date().getFullYear()} BloodDonate. All rights reserved.</p>
                                                    <p style="margin: 0 0 12px 0; color: #9ca3af; font-size: 12px; line-height: 1.6;">This is your weekly summary email.</p>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>

                            </table>
                        </td>
                    </tr>
                </table>
            </body>
        </html>
        `;

		return await this.sendEmail({ to: donor.email, subject, html });
	}
}

export const emailService = new EmailService();
